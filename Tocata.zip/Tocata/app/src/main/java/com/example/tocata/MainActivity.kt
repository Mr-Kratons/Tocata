package com.example.tocata

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.example.tocata.ui.TocataRoot

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        setContent { TocataRoot() }
    }

    override fun onStop() {
        super.onStop()
        (application as TocataApp).player.persist()
    }
}
