package com.example.tocata

import android.app.Application
import com.example.tocata.data.MusicRepository
import com.example.tocata.data.Prefs
import com.example.tocata.playback.PlayerController

class TocataApp : Application() {
    lateinit var prefs: Prefs
        private set
    lateinit var repository: MusicRepository
        private set
    lateinit var player: PlayerController
        private set

    override fun onCreate() {
        super.onCreate()
        prefs = Prefs(this)
        repository = MusicRepository(this, prefs)
        player = PlayerController(this, repository, prefs)
    }
}
